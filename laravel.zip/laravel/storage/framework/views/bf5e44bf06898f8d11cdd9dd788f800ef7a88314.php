<!DOCTYPE html>
<html>
<head>
    <title>student list </title>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/bootstrap.min.css')); ?>"/>
    <link href="<?php echo e(asset('assets/jquery.dataTables.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet">

    
</head>
<body>
    
<div class="container mt-5">
    <h2 class="mb-4"> Student list</h2>
    <table class="table table-bordered yajra-datatable" id='table_id'>
        <thead>
            <tr>
                <th>No</th>
                <th>Name</th>
                <th>Email</th>
                <th>Username</th>
                <th>Phone</th>
                <th></th> 
            </tr>
        </thead>
    </table>
</div>
   
</body>
<script src="<?php echo e(asset('assets/jquery.js')); ?>"></script>  
<script src="<?php echo e(asset('assets/jquery.validate.js')); ?>"></script>
<script src="<?php echo e(asset('assets/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/dataTables.bootstrap4.min.js')); ?>"></script>


<script type="text/javascript">
  $(function () {
     $('.yajra-datatable').DataTable({
        processing: true,
        serverSide: true,
        searching: true,
        order: [],
        ordering: false,
        // ajax: "<?php echo e(url('students/list')); ?>",
         ajax: "<?php echo e(route('students.list')); ?>",
        columns: [
            {data: 'id',name:'id'},
            {data: 'name',name:'name'},
            {data: 'email',name:'email'},
            {data: 'username',name:'username'},
            {data: 'phone',name:'phone'},
            {
                data: 'action', 
                name: 'action', 
                orderable: true, 
                searchable: true
            },
        ]
    });

  });
</script>
</html><?php /**PATH /var/www/html/laravel-yajra-datatables/resources/views/studentList.blade.php ENDPATH**/ ?>