<!DOCTYPE html>
<html>
<head>
    <title>student list </title>
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <link rel="stylesheet" href="{{ asset('assets/bootstrap.min.css') }}"/>
    <link href="{{ asset('assets/jquery.dataTables.min.css') }}" rel="stylesheet">
    <link href="{{ asset('assets/dataTables.bootstrap4.min.css') }}" rel="stylesheet">

    
</head>
<body>
    
<div class="container mt-5">
    <h2 class="mb-4"> Student list</h2>
    <table class="table table-bordered yajra-datatable" id='table_id'>
        <thead>
            <tr>
                <th>No</th>
                <th>Name</th>
                <th>Email</th>
                <th>Username</th>
                <th>Phone</th>
            </tr>
        </thead>
    </table>
</div>
   
</body>
<script src="{{ asset('assets/jquery.js') }}"></script>  
<script src="{{ asset('assets/jquery.validate.js') }}"></script>
<script src="{{ asset('assets/jquery.dataTables.min.js') }}"></script>
<script src="{{ asset('assets/bootstrap.min.js') }}"></script>
<script src="{{ asset('assets/dataTables.bootstrap4.min.js') }}"></script>


<script type="text/javascript">
  $(function () {
     $('.yajra-datatable').DataTable({
        processing: true,
        serverSide: true,
        searching: true,
        order: [],
        ordering: false,
        ajax: "{{ route('students.list') }}",
        columns: [
                { "data": "id" },
                { "data": "name" },
                { "data": "email" },
                { "data": "username" },
                { "data": "phone" }
            ]    
    });

  });
</script>
</html>