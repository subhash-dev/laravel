<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Student;
use DataTables;

class StudentController extends Controller
{	
	/*view page Student record*/
    public function index()
    {
        return view('studentList');
    }

    /*get record using ajax call*/
    public function getStudents(Request $request)
    {		
        $totalData = Student::count();
        $totalFiltered = $totalData; 
        $limit = $request->length;
        $start = $request->start;
        if ($request->ajax()) {
            $newData = Student::orderBy('id', 'DESC')
            				->OrWhere('name', 'like', '%' . $request->search['value']. '%')
            				->OrWhere('email', 'like', '%' . $request->search['value']. '%')
            				->OrWhere('username', 'like', '%' . $request->search['value']. '%')
            				->OrWhere('phone', 'like', '%' . $request->search['value']. '%')
                            ->offset($start)
                            ->limit($limit)
            				->get();
        }
        $data = array();
        if(!empty($newData))
        {
            foreach ($newData as $post)
            {

                $nestedData['id'] = $post['id'];
                $nestedData['name'] = $post['name'];
                $nestedData['email'] = $post['email'];
                $nestedData['username'] = $post['username'];
                $nestedData['phone'] = $post['phone'];
                $data[] = $nestedData;

            }
        }
       return $json_data = array(
                    "draw"            => intval($request->draw),  
                    "recordsTotal"    => intval($totalData),  
                    "recordsFiltered" => intval($totalFiltered), 
                    "data"            => $data   
                    );
    }
}